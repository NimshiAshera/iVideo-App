package com.example.app_nadun;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class addVideos extends AppCompatActivity {

    EditText videoName,videoQuantity,videoPrice;
    Context context = this;
    DataBaseHelper dataBaseHelper;
    SQLiteDatabase sqLiteDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_videos);

        videoName = (EditText)findViewById(R.id.et1);
        videoQuantity = (EditText)findViewById(R.id.et2);
        videoPrice = (EditText)findViewById(R.id.et3);
    }

    public void addVideo(View view){

        String name = videoName.getText().toString();
        String quantity = videoQuantity.getText().toString();
        String price = videoPrice.getText().toString();

        dataBaseHelper = new DataBaseHelper(context);
        sqLiteDatabase = dataBaseHelper.getWritableDatabase();
        dataBaseHelper.addVideoInformation(name,quantity,price,sqLiteDatabase);

        Toast.makeText(getBaseContext(),"Data Saved",Toast.LENGTH_LONG).show();
    }

}
