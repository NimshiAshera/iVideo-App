package com.example.app_nadun;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

public class VideoList extends AppCompatActivity {

    ListView listView;
    SQLiteDatabase sqLiteDatabase;
    DataBaseHelper dataBaseHelper;
    Cursor cursor;
    ListVideoAdapter listVideoAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_list);

        listView = (ListView)findViewById(R.id.list_view);
        listVideoAdapter = new ListVideoAdapter(getApplicationContext(),R.layout.row_layout);
        listView.setAdapter(listVideoAdapter);
        dataBaseHelper = new DataBaseHelper(getApplicationContext());
        sqLiteDatabase = dataBaseHelper.getReadableDatabase();
        cursor = dataBaseHelper.getVideoInformation(sqLiteDatabase);
        if(cursor.moveToFirst()){
            do{

                String videoname,videoquantity,videoprice;
                videoname = cursor.getString(0);
                videoquantity = cursor.getString(1);
                videoprice = cursor.getString(2);
                DataProvider dataProvider = new DataProvider(videoname,videoquantity,videoprice);
                listVideoAdapter.add(dataProvider);

            }while(cursor.moveToNext());
        }
    }
}
