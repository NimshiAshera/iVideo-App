package com.example.app_nadun;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class updateVideo extends AppCompatActivity {

    EditText Name_Search,New_Name,New_Quantity,New_Price;
    Button UpdateButton;
    TextView title;
    DataBaseHelper dataBaseHelper;
    SQLiteDatabase sqLiteDatabase;
    String SearchName,NewName,NewQuantity,NewPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_video);

        Name_Search = (EditText)findViewById(R.id.etts1);
        New_Name = (EditText) findViewById(R.id.etts2);
        New_Quantity =(EditText) findViewById(R.id.etts3);
        New_Price = (EditText) findViewById(R.id.etts4);
        UpdateButton = (Button)findViewById(R.id.update_button);
        title = (TextView)findViewById(R.id.ttv1);
        New_Name.setVisibility(View.GONE);
        New_Quantity.setVisibility(View.GONE);
        New_Price.setVisibility(View.GONE);
        UpdateButton.setVisibility(View.GONE);
        title.setVisibility(View.GONE);

    }

    public void searchVideo(View view){
        SearchName = Name_Search.getText().toString();
        dataBaseHelper = new DataBaseHelper(getApplicationContext());
        sqLiteDatabase = dataBaseHelper.getReadableDatabase();
        Cursor cursor = dataBaseHelper.getVideo(SearchName,sqLiteDatabase);

        if(cursor.moveToFirst()){
            NewQuantity = cursor.getString(1);
            NewPrice = cursor.getString(2);
            NewName = SearchName;

            New_Name.setText(NewName);
            New_Quantity.setText(NewQuantity);
            New_Price.setText(NewPrice);

            New_Name.setVisibility(View.VISIBLE);
            New_Quantity.setVisibility(View.VISIBLE);
            New_Price.setVisibility(View.VISIBLE);
            UpdateButton.setVisibility(View.VISIBLE);
            title.setVisibility(View.VISIBLE);

        }
    }

    public void updateVideo(View view){
        dataBaseHelper = new DataBaseHelper(getApplicationContext());
        sqLiteDatabase = dataBaseHelper.getReadableDatabase();

        String name,quantity,price;

        name = New_Name.getText().toString();
        quantity = New_Quantity.getText().toString();
        price = New_Price.getText().toString();
        int count = dataBaseHelper.updateVideoInformation(SearchName,name,quantity,price,sqLiteDatabase);
        Toast.makeText(getApplicationContext(),count+" video Updated",Toast.LENGTH_LONG).show();
        finish();
    }

}
