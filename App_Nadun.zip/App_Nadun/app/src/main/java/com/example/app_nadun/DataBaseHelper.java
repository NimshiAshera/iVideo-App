package com.example.app_nadun;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.TableRow;

public class DataBaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "videoapp.db";
    
    //--------------------------------------------------------------------------------------------------------------------------

    public static final String TABLE_NAME = "videotable";
    public static final String COLS_1 = "video_name";
    public static final String COLS_2 = "video_quantity";
    public static final String COLS_3 = "video_price";
    private DataBaseHelper db;


    //----------------------------------------------------------------------------------------------------------------------------

    public DataBaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
        SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME +" (video_name TEXT PRIMARY KEY,video_quantity TEXT,video_price Text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
    
    //---------------------------------------------------------------------------------------------------------------------------------------
    
    //--------------------------------------------------------------------------------------------------------------------------------------

    public void addVideoInformation(String name,String quantity,String price,SQLiteDatabase db){
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLS_1,name);
        contentValues.put(COLS_2,quantity);
        contentValues.put(COLS_3,price);
        db.insert(TABLE_NAME,null,contentValues);

    }

    public Cursor getVideoInformation(SQLiteDatabase db){

        Cursor cursor;
        String[] projections = {COLS_1,COLS_2,COLS_3};
        cursor = db.query(TABLE_NAME,projections,null,null,null,null,null);
        return cursor;
    }

    public Cursor getVideo(String name,SQLiteDatabase sqLiteDatabase){
        String[] projections = {COLS_1,COLS_2,COLS_3};
        String selection = COLS_1+" LIKE ?";
        String[] selection_args = {name};
        Cursor cursor = sqLiteDatabase.query(TABLE_NAME,projections,selection,selection_args,null,null,null);
        return cursor;
    }

    public void deleteVideoInformation(String name,SQLiteDatabase sqLiteDatabase){
        String selection = COLS_1+" LIKE ?";
        String[] selection_args = {name};
        sqLiteDatabase.delete(TABLE_NAME,selection,selection_args);
    }

    public int updateVideoInformation(String oldName,String newName,String newquantity,String newprice,SQLiteDatabase sqLiteDatabase ){
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLS_1,newName);
        contentValues.put(COLS_2,newquantity);
        contentValues.put(COLS_3,newprice);

        String selection = COLS_1+" LIKE ?";
        String[] selection_args = {oldName};
        int count = sqLiteDatabase.update(TABLE_NAME,contentValues,selection,selection_args);

        return count;
    }


}
