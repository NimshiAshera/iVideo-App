package com.example.app_nadun;

public class DataProvider {

    private String videoname;
    private  String videoquantity;
    private String videoprice;

    public DataProvider(String videoname,String videoquantity,String videoprice){
        this.videoname = videoname;
        this.videoquantity = videoquantity;
        this.videoprice = videoprice;
    }

    public String getVideoname(){
        return  videoname;
    }

    public void setVideoname(String videonamename){
        this.videoname = videonamename;
    }

    public String getVideoquantity(){
        return  videoquantity;
    }

    public void setVideoquantity(String videoquantity){
        this.videoquantity = videoquantity;
    }

    public String getVideoprice(){
        return  videoprice;
    }

    public void setVideoprice(String videoprice){
        this.videoprice = videoprice;
    }

}
