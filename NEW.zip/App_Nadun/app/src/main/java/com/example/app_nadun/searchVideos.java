package com.example.app_nadun;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class searchVideos extends AppCompatActivity {

    TextView videoName,videoQuantity,videoPrice;
    EditText searchVideo;
    DataBaseHelper dataBaseHelper;
    SQLiteDatabase sqLiteDatabase;
    String search_video;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_videos);

        searchVideo = (EditText)findViewById(R.id.ett1);
        videoName = (TextView)findViewById(R.id.tvv1);
        videoQuantity =(TextView)findViewById(R.id.tvv2);
        videoPrice = (TextView)findViewById(R.id.tvv3);

        videoName.setVisibility(View.GONE);
        videoQuantity.setVisibility(View.GONE);
        videoPrice.setVisibility(View.GONE);



    }

    public void searchVideo(View view){
        search_video = searchVideo.getText().toString();
        dataBaseHelper = new DataBaseHelper(getApplicationContext());
        sqLiteDatabase = dataBaseHelper.getReadableDatabase();
        Cursor cursor = dataBaseHelper.getVideo(search_video,sqLiteDatabase);

        if(cursor.moveToFirst()){

            Toast.makeText(getBaseContext(),"Video Available",Toast.LENGTH_LONG).show();


            String name = cursor.getString(0);
            String quantity = cursor.getString(1);
            String price = cursor.getString(2);

            videoName.setText(name);
            videoQuantity.setText(quantity);
            videoPrice.setText(price);

            videoName.setVisibility(View.VISIBLE);
            videoQuantity.setVisibility(View.VISIBLE);
            videoPrice.setVisibility(View.VISIBLE);
        }
        else{
            Toast.makeText(getBaseContext(),"No Video",Toast.LENGTH_LONG).show();
        }


    }

    public void deleteVideo(View view){

        dataBaseHelper = new DataBaseHelper(getApplicationContext());
        sqLiteDatabase = dataBaseHelper.getReadableDatabase();
        dataBaseHelper.deleteVideoInformation(search_video,sqLiteDatabase);
        Toast.makeText(getBaseContext(),"Video Deleted",Toast.LENGTH_LONG).show();

    }



}
