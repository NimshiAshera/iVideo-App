package com.example.app_nadun;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class ContentActivity extends AppCompatActivity {

    DataBaseHelper mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content);
        mydb = new DataBaseHelper(this);
    }

    public void addVideoContact(View view) {
        Intent intent = new Intent(this, addVideos.class);
        startActivity(intent);
    }

    public void viewVideo(View view) {
        Intent intent = new Intent(this, VideoList.class);
        startActivity(intent);
    }

    public void searchVideo(View view) {
        Intent intent = new Intent(this, searchVideos.class);
        startActivity(intent);
    }

    public void updateVideo(View view) {
        Intent intent = new Intent(this, updateVideo.class);
        startActivity(intent);
    }

}
